# Homework 1

## 1. Identify and enumerate all the tokens in the program

1. `program`
2. `minipas`
3. `;`
4. `var`
5. `a`
6. `integer`
7. `b`
8. `i`
9. `x`
10. `array`
11. `of real`
12. `function`
13. `begin`
14. `while`
15. `do`
16. `if`
17. `then`
18. `else`
19. `end`
20. `boolean`
21. `true`
22. `:=`
23. 