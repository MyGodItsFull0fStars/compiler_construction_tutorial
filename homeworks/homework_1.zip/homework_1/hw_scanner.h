// 

#define PROGRAM 1
#define IDENTIFIER 2
#define SEMICOLON 3
#define COLON 4
#define VAR 5
#define INTEGER_KW 6
#define ARRAY 7
#define COMMA 8
#define OP 9
#define REL 10
#define ASSIGN 11
#define BEGIN_KW 12
#define END_KW 13
#define FUNCTION 14
#define COND 15
#define COMMENT 16
#define INTEGER 17
#define BOOLEAN 18
#define KEYWORD 19
#define TYPE 20
#define FLOAT 21
#define PARANTHESIS 22
#define BRACKET 23
#define ARRAY_DEC 24
#define DOT 25
#define ERROR 26